import java.util.*;


public class Search {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
       List<String> names=new ArrayList<>();
       names.add("john");
       names.add("maria");
       names.add("vishu");
       names.add("piku");
       System.out.println("does name array contain any name" +  names.contains("maria"));
	}
	

}
