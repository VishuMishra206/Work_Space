package mockitoTest;

public interface CalculatorService 
{
   public int add(int i, int j);
	
}
