package mockitoTest;

public class Calculator {

	public Calculator(CalculatorService service2)
	{
		
	}

	public int add(int i, int j)
	{
		//service.add(2,3);
		return (i+j)*i;
		
	}
}
